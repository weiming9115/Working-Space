this is a package for moist static energy (MSE) plots. 
